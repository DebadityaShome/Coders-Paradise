stack = []

stack.append(1)
stack.append(2)
stack.append(3)
stack.append(4)

print(stack)

x = stack.pop()
print(x)
print(stack)